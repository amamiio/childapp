# Add project specific ProGuard rules here.
-keep class com.parentalcontrol.child.data.remote.dto.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
