package com.parentalcontrol.child.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "location_samples")
data class LocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val capturedAtEpochMillis: Long,
    val synced: Boolean = false
)

@Entity(tableName = "notification_events")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val title: String?,
    val text: String?,
    val postedAtEpochMillis: Long,
    val synced: Boolean = false
)

@Entity(tableName = "locked_app_rules")
data class LockedAppRuleEntity(
    @PrimaryKey val packageName: String,
    val isLocked: Boolean
)
