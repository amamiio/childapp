package com.parentalcontrol.child.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.parentalcontrol.child.data.local.entity.LocationEntity
import com.parentalcontrol.child.data.local.entity.LockedAppRuleEntity
import com.parentalcontrol.child.data.local.entity.NotificationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LocationDao {
    @Insert
    suspend fun insert(entity: LocationEntity)

    @Query("SELECT * FROM location_samples WHERE synced = 0 ORDER BY capturedAtEpochMillis ASC")
    suspend fun getUnsynced(): List<LocationEntity>

    @Query("UPDATE location_samples SET synced = 1 WHERE capturedAtEpochMillis <= :upTo")
    suspend fun markSynced(upTo: Long)

    @Query("DELETE FROM location_samples WHERE synced = 1 AND capturedAtEpochMillis < :olderThan")
    suspend fun pruneSynced(olderThan: Long)
}

@Dao
interface NotificationDao {
    @Insert
    suspend fun insert(entity: NotificationEntity)

    @Query("SELECT * FROM notification_events WHERE synced = 0 ORDER BY postedAtEpochMillis ASC")
    suspend fun getUnsynced(): List<NotificationEntity>

    @Query("UPDATE notification_events SET synced = 1 WHERE postedAtEpochMillis <= :upTo")
    suspend fun markSynced(upTo: Long)

    @Query("DELETE FROM notification_events WHERE synced = 1 AND postedAtEpochMillis < :olderThan")
    suspend fun pruneSynced(olderThan: Long)
}

@Dao
interface LockedAppRuleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rules: List<LockedAppRuleEntity>)

    @Query("SELECT * FROM locked_app_rules")
    fun observeAll(): Flow<List<LockedAppRuleEntity>>

    @Query("DELETE FROM locked_app_rules")
    suspend fun clear()
}
