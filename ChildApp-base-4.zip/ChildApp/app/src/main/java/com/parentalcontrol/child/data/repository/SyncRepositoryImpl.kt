package com.parentalcontrol.child.data.repository

import com.parentalcontrol.child.data.remote.ChildApiService
import com.parentalcontrol.child.data.remote.dto.AppUsageDto
import com.parentalcontrol.child.data.remote.dto.AppUsagePayloadDto
import com.parentalcontrol.child.data.remote.dto.InstalledAppDto
import com.parentalcontrol.child.data.remote.dto.InstalledAppsPayloadDto
import com.parentalcontrol.child.data.remote.dto.LocationBatchDto
import com.parentalcontrol.child.data.remote.dto.LocationSampleDto
import com.parentalcontrol.child.data.remote.dto.NotificationBatchDto
import com.parentalcontrol.child.data.remote.dto.NotificationEventDto
import com.parentalcontrol.child.domain.model.LockedAppRule
import com.parentalcontrol.child.domain.repository.AppUsageRepository
import com.parentalcontrol.child.domain.repository.InstalledAppsRepository
import com.parentalcontrol.child.domain.repository.LocationRepository
import com.parentalcontrol.child.domain.repository.NotificationRepository
import com.parentalcontrol.child.domain.repository.SyncRepository
import javax.inject.Inject

class SyncRepositoryImpl @Inject constructor(
    private val api: ChildApiService,
    private val locationRepository: LocationRepository,
    private val installedAppsRepository: InstalledAppsRepository,
    private val appUsageRepository: AppUsageRepository,
    private val notificationRepository: NotificationRepository
) : SyncRepository {

    override suspend fun syncAll(): Boolean {
        return try {
            syncLocations()
            syncInstalledApps()
            syncAppUsage()
            syncNotifications()
            pullPendingCommands()
            true
        } catch (e: Exception) {
            false
        }
    }

    private suspend fun syncLocations() {
        val pending = locationRepository.getUnsyncedLocations()
        if (pending.isEmpty()) return
        val response = api.uploadLocationBatch(
            LocationBatchDto(pending.map {
                LocationSampleDto(it.latitude, it.longitude, it.accuracyMeters, it.capturedAtEpochMillis)
            })
        )
        if (response.isSuccessful) {
            locationRepository.markLocationsSynced(pending.maxOf { it.capturedAtEpochMillis })
        }
    }

    private suspend fun syncInstalledApps() {
        val apps = installedAppsRepository.getInstalledApps()
        api.uploadInstalledApps(
            InstalledAppsPayloadDto(apps.map { InstalledAppDto(it.packageName, it.appLabel, it.isSystemApp) })
        )
    }

    private suspend fun syncAppUsage() {
        val usage = appUsageRepository.getUsageForToday()
        api.uploadAppUsage(
            AppUsagePayloadDto(usage.map { AppUsageDto(it.packageName, it.foregroundMillisToday) })
        )
    }

    private suspend fun syncNotifications() {
        val pending = notificationRepository.getUnsyncedNotifications()
        if (pending.isEmpty()) return
        val response = api.uploadNotificationBatch(
            NotificationBatchDto(pending.map {
                NotificationEventDto(it.packageName, it.title, it.text, it.postedAtEpochMillis)
            })
        )
        if (response.isSuccessful) {
            notificationRepository.markNotificationsSynced(pending.maxOf { it.postedAtEpochMillis })
        }
    }

    private suspend fun pullPendingCommands() {
        val response = api.getPendingCommands()
        val body = response.body() ?: return
        if (response.isSuccessful) {
            val allApps = installedAppsRepository.getInstalledApps().map { it.packageName }
            val rules = allApps.map { pkg ->
                LockedAppRule(pkg, isLocked = body.lockedPackages.contains(pkg))
            }
            installedAppsRepository.setLockedApps(rules)
        }
    }
}
