package com.parentalcontrol.child.utils

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * Toggles visibility of the launcher icon using the official activity-alias
 * component-enable API. This never touches the app's presence in
 * Settings > Apps, its ability to be force-stopped, or its ability to be
 * uninstalled -- it only controls whether a launcher shortcut exists.
 *
 * The user (via the on-device confirmation screen) explicitly chooses
 * whether to hide the icon; nothing here happens silently.
 */
object IconVisibilityManager {

    fun setLauncherIconVisible(context: Context, visible: Boolean) {
        val pm = context.packageManager
        val alias = ComponentName(context, Constants.LAUNCHER_ALIAS_CLASS)
        val newState = if (visible) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        } else {
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED
        }
        pm.setComponentEnabledSetting(alias, newState, PackageManager.DONT_KILL_APP)
    }
}
