package com.parentalcontrol.child.domain.model

data class PairingResult(
    val success: Boolean,
    val childDeviceId: String? = null,
    val errorMessage: String? = null
)

data class LocationSample(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val capturedAtEpochMillis: Long
)

data class InstalledAppInfo(
    val packageName: String,
    val appLabel: String,
    val isSystemApp: Boolean
)

data class AppUsageSample(
    val packageName: String,
    val foregroundMillisToday: Long
)

data class NotificationEvent(
    val packageName: String,
    val title: String?,
    val text: String?,
    val postedAtEpochMillis: Long
)

/** A single package the parent wants locked; enforced by the accessibility service. */
data class LockedAppRule(
    val packageName: String,
    val isLocked: Boolean
)

enum class SyncEntityType {
    LOCATION, INSTALLED_APPS, APP_USAGE, NOTIFICATION
}
