package com.parentalcontrol.child.ui.permissions

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.parentalcontrol.child.R
import com.parentalcontrol.child.services.DeviceAdminReceiverImpl

@Composable
fun PermissionsScreen(
    viewModel: PermissionsViewModel = viewModel(),
    onAllGranted: () -> Unit
) {
    val context = LocalContext.current
    val states by viewModel.states.collectAsState()

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.refresh() }

    val mediaLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.refresh() }

    LaunchedEffect(Unit) { viewModel.refresh() }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(states) { state ->
                PermissionRow(
                    state = state,
                    onGrantClick = {
                        when (state.key) {
                            PermissionKey.LOCATION -> locationLauncher.launch(
                                arrayOf(
                                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                            PermissionKey.MEDIA -> mediaLauncher.launch(
                                arrayOf(
                                    android.Manifest.permission.READ_MEDIA_IMAGES,
                                    android.Manifest.permission.READ_MEDIA_VIDEO
                                )
                            )
                            PermissionKey.NOTIFICATION_LISTENER -> context.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                            )
                            PermissionKey.ACCESSIBILITY -> context.startActivity(
                                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            )
                            PermissionKey.USAGE_ACCESS -> context.startActivity(
                                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                            )
                            PermissionKey.DEVICE_ADMIN -> {
                                val admin = android.content.ComponentName(context, DeviceAdminReceiverImpl::class.java)
                                context.startActivity(
                                    Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                        putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                                        putExtra(
                                            android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                            context.getString(R.string.permission_device_admin_body)
                                        )
                                    }
                                )
                            }
                        }
                    }
                )
            }
        }
        Button(
            modifier = Modifier.padding(top = 12.dp),
            onClick = { viewModel.refresh(); if (viewModel.allRequiredGranted()) onAllGranted() }
        ) {
            Text(stringResource(R.string.welcome_continue))
        }
    }
}

@Composable
private fun PermissionRow(state: PermissionUiState, onGrantClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(titleFor(state.key), style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            Text(bodyFor(state.key), style = androidx.compose.material3.MaterialTheme.typography.bodyMedium)
            if (!state.granted) {
                Button(modifier = Modifier.padding(top = 8.dp), onClick = onGrantClick) {
                    Text(stringResource(R.string.permission_grant))
                }
            } else {
                Text("✓")
            }
        }
    }
}

@Composable
private fun titleFor(key: PermissionKey): String = when (key) {
    PermissionKey.LOCATION -> stringResource(R.string.permission_location_title)
    PermissionKey.NOTIFICATION_LISTENER -> stringResource(R.string.permission_notification_title)
    PermissionKey.ACCESSIBILITY -> stringResource(R.string.permission_accessibility_title)
    PermissionKey.USAGE_ACCESS -> stringResource(R.string.permission_usage_title)
    PermissionKey.MEDIA -> stringResource(R.string.permission_media_title)
    PermissionKey.DEVICE_ADMIN -> stringResource(R.string.permission_device_admin_title)
}

@Composable
private fun bodyFor(key: PermissionKey): String = when (key) {
    PermissionKey.LOCATION -> stringResource(R.string.permission_location_body)
    PermissionKey.NOTIFICATION_LISTENER -> stringResource(R.string.permission_notification_body)
    PermissionKey.ACCESSIBILITY -> stringResource(R.string.permission_accessibility_body)
    PermissionKey.USAGE_ACCESS -> stringResource(R.string.permission_usage_body)
    PermissionKey.MEDIA -> stringResource(R.string.permission_media_body)
    PermissionKey.DEVICE_ADMIN -> stringResource(R.string.permission_device_admin_body)
}
