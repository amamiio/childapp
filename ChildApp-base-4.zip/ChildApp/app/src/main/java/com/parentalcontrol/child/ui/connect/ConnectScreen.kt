package com.parentalcontrol.child.ui.connect

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.parentalcontrol.child.R

@Composable
fun ConnectScreen(
    onPaired: () -> Unit,
    viewModel: ConnectViewModel = hiltViewModel()
) {
    var password by remember { mutableStateOf("") }
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState) {
        if (uiState is ConnectUiState.Success) onPaired()
    }

    Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
        Text(stringResource(R.string.connect_title), style = androidx.compose.material3.MaterialTheme.typography.headlineSmall)
        Text(stringResource(R.string.connect_body), modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text(stringResource(R.string.connect_code_hint)) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            modifier = Modifier.padding(top = 12.dp).fillMaxWidth(),
            onClick = { viewModel.submitCode(password) },
            enabled = uiState !is ConnectUiState.Loading
        ) {
            Text(stringResource(R.string.connect_submit))
        }

        when (uiState) {
            is ConnectUiState.Loading -> CircularProgressIndicator(modifier = Modifier.padding(top = 16.dp))
            is ConnectUiState.Error -> Text(
                stringResource(R.string.connect_error),
                modifier = Modifier.padding(top = 16.dp)
            )
            is ConnectUiState.Success -> Text(
                stringResource(R.string.connect_success),
                modifier = Modifier.padding(top = 16.dp)
            )
            else -> {}
        }
    }
}
