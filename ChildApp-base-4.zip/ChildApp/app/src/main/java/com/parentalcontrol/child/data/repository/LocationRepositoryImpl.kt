package com.parentalcontrol.child.data.repository

import com.parentalcontrol.child.data.local.dao.LocationDao
import com.parentalcontrol.child.data.local.entity.LocationEntity
import com.parentalcontrol.child.domain.model.LocationSample
import com.parentalcontrol.child.domain.repository.LocationRepository
import javax.inject.Inject

class LocationRepositoryImpl @Inject constructor(
    private val dao: LocationDao
) : LocationRepository {

    override suspend fun recordLocation(sample: LocationSample) {
        dao.insert(
            LocationEntity(
                latitude = sample.latitude,
                longitude = sample.longitude,
                accuracyMeters = sample.accuracyMeters,
                capturedAtEpochMillis = sample.capturedAtEpochMillis
            )
        )
    }

    override suspend fun getUnsyncedLocations(): List<LocationSample> =
        dao.getUnsynced().map {
            LocationSample(it.latitude, it.longitude, it.accuracyMeters, it.capturedAtEpochMillis)
        }

    override suspend fun markLocationsSynced(upToEpochMillis: Long) {
        dao.markSynced(upToEpochMillis)
    }
}
