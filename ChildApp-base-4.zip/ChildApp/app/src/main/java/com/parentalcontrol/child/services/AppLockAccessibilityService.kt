package com.parentalcontrol.child.services

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.parentalcontrol.child.domain.repository.InstalledAppsRepository
import com.parentalcontrol.child.ui.lock.AppLockOverlayActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Watches for foreground app changes (window state events) and, if the
 * foreground package is on the parent-configured lock list, launches a
 * full-screen overlay blocking further interaction with it. This uses only
 * the standard AccessibilityService window-change callback; it does not
 * read arbitrary screen content.
 */
@AndroidEntryPoint
class AppLockAccessibilityService : AccessibilityService() {

    @Inject lateinit var installedAppsRepository: InstalledAppsRepository

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (packageName == this.packageName) return

        scope.launch {
            val lockedRules = installedAppsRepository.observeLockedApps().first()
            val isLocked = lockedRules.any { it.packageName == packageName && it.isLocked }
            if (isLocked) {
                val intent = Intent(this@AppLockAccessibilityService, AppLockOverlayActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra(AppLockOverlayActivity.EXTRA_LOCKED_PACKAGE, packageName)
                }
                startActivity(intent)
            }
        }
    }

    override fun onInterrupt() {}
}
