package com.parentalcontrol.child.ui.iconvisibility

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.parentalcontrol.child.R
import com.parentalcontrol.child.data.local.SessionStore
import com.parentalcontrol.child.utils.IconVisibilityManager
import kotlinx.coroutines.launch

/**
 * Asks explicitly, on-device, whether the launcher icon should be hidden.
 * This choice is never made silently by the app itself -- it is always a
 * deliberate action taken on the device it applies to, and it can be
 * reversed at any time from Settings > Apps > [app name].
 */
@Composable
fun IconVisibilityScreen(
    sessionStore: SessionStore,
    onDone: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(R.string.hide_icon_title), style = androidx.compose.material3.MaterialTheme.typography.headlineSmall)
        Text(
            stringResource(R.string.hide_icon_body),
            modifier = Modifier.padding(top = 12.dp, bottom = 24.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Button(onClick = {
            IconVisibilityManager.setLauncherIconVisible(context, visible = false)
            scope.launch { sessionStore.setIconHidden(true); onDone() }
        }) {
            Text(stringResource(R.string.hide_icon_confirm))
        }
        OutlinedButton(
            modifier = Modifier.padding(top = 8.dp),
            onClick = {
                IconVisibilityManager.setLauncherIconVisible(context, visible = true)
                scope.launch { sessionStore.setIconHidden(false); onDone() }
            }
        ) {
            Text(stringResource(R.string.hide_icon_keep))
        }
    }
}
