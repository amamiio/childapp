package com.parentalcontrol.child.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.parentalcontrol.child.utils.Constants
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = Constants.DATASTORE_NAME)

/** Provided as a singleton via [com.parentalcontrol.child.di.DatabaseModule]. */
class SessionStore(context: Context) {

    private val appContext = context.applicationContext

    private object Keys {
        val TOKEN = stringPreferencesKey(Constants.KEY_PAIRING_TOKEN)
        val DEVICE_ID = stringPreferencesKey(Constants.KEY_CHILD_DEVICE_ID)
        val ICON_HIDDEN = booleanPreferencesKey(Constants.KEY_ICON_HIDDEN)
    }

    val authTokenFlow: Flow<String?> = appContext.dataStore.data.map { it[Keys.TOKEN] }
    val deviceIdFlow: Flow<String?> = appContext.dataStore.data.map { it[Keys.DEVICE_ID] }

    suspend fun currentToken(): String? = authTokenFlow.first()
    suspend fun currentDeviceId(): String? = deviceIdFlow.first()

    suspend fun savePairing(token: String, deviceId: String) {
        appContext.dataStore.edit {
            it[Keys.TOKEN] = token
            it[Keys.DEVICE_ID] = deviceId
        }
    }

    suspend fun setIconHidden(hidden: Boolean) {
        appContext.dataStore.edit { it[Keys.ICON_HIDDEN] = hidden }
    }

    suspend fun isIconHidden(): Boolean =
        appContext.dataStore.data.map { it[Keys.ICON_HIDDEN] ?: false }.first()

    suspend fun clear() {
        appContext.dataStore.edit { it.clear() }
    }
}
