package com.parentalcontrol.child.data.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.parentalcontrol.child.data.local.dao.LockedAppRuleDao
import com.parentalcontrol.child.data.local.entity.LockedAppRuleEntity
import com.parentalcontrol.child.domain.model.InstalledAppInfo
import com.parentalcontrol.child.domain.model.LockedAppRule
import com.parentalcontrol.child.domain.repository.InstalledAppsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class InstalledAppsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val lockedAppRuleDao: LockedAppRuleDao
) : InstalledAppsRepository {

    override suspend fun getInstalledApps(): List<InstalledAppInfo> {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        return apps.map { info: ApplicationInfo ->
            InstalledAppInfo(
                packageName = info.packageName,
                appLabel = pm.getApplicationLabel(info).toString(),
                isSystemApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        }
    }

    override fun observeLockedApps(): Flow<List<LockedAppRule>> =
        lockedAppRuleDao.observeAll().map { list ->
            list.map { LockedAppRule(it.packageName, it.isLocked) }
        }

    override suspend fun setLockedApps(rules: List<LockedAppRule>) {
        lockedAppRuleDao.upsertAll(rules.map { LockedAppRuleEntity(it.packageName, it.isLocked) })
    }
}
