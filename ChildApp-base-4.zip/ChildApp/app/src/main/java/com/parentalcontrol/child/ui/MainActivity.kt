package com.parentalcontrol.child.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.parentalcontrol.child.data.local.SessionStore
import com.parentalcontrol.child.ui.navigation.ChildNavGraph
import com.parentalcontrol.child.ui.theme.ChildAppTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var sessionStore: SessionStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ChildAppTheme {
                ChildNavGraph(sessionStore = sessionStore)
            }
        }
    }
}
