package com.parentalcontrol.child.di

import android.content.Context
import androidx.room.Room
import com.parentalcontrol.child.data.local.AppDatabase
import com.parentalcontrol.child.data.local.SessionStore
import com.parentalcontrol.child.data.local.dao.LocationDao
import com.parentalcontrol.child.data.local.dao.LockedAppRuleDao
import com.parentalcontrol.child.data.local.dao.NotificationDao
import com.parentalcontrol.child.utils.Constants
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, Constants.DATABASE_NAME)
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideLocationDao(db: AppDatabase): LocationDao = db.locationDao()

    @Provides
    fun provideNotificationDao(db: AppDatabase): NotificationDao = db.notificationDao()

    @Provides
    fun provideLockedAppRuleDao(db: AppDatabase): LockedAppRuleDao = db.lockedAppRuleDao()

    @Provides
    @Singleton
    fun provideSessionStore(@ApplicationContext context: Context): SessionStore =
        SessionStore(context)
}
