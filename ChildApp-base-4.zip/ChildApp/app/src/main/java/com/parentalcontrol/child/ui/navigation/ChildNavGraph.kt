package com.parentalcontrol.child.ui.navigation

import android.content.Intent
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.parentalcontrol.child.data.local.SessionStore
import com.parentalcontrol.child.services.MonitoringForegroundService
import com.parentalcontrol.child.ui.connect.ConnectScreen
import com.parentalcontrol.child.ui.iconvisibility.IconVisibilityScreen
import com.parentalcontrol.child.ui.permissions.PermissionsScreen
import com.parentalcontrol.child.ui.welcome.WelcomeScreen

private object Routes {
    const val WELCOME = "welcome"
    const val PERMISSIONS = "permissions"
    const val CONNECT = "connect"
    const val ICON_VISIBILITY = "icon_visibility"
    const val DONE = "done"
}

@Composable
fun ChildNavGraph(sessionStore: SessionStore) {
    val navController = rememberNavController()
    val context = LocalContext.current

    NavHost(navController = navController, startDestination = Routes.WELCOME) {
        composable(Routes.WELCOME) {
            WelcomeScreen(onContinue = { navController.navigate(Routes.PERMISSIONS) })
        }
        composable(Routes.PERMISSIONS) {
            PermissionsScreen(onAllGranted = { navController.navigate(Routes.CONNECT) })
        }
        composable(Routes.CONNECT) {
            ConnectScreen(
                onPaired = { navController.navigate(Routes.ICON_VISIBILITY) }
            )
        }
        composable(Routes.ICON_VISIBILITY) {
            IconVisibilityScreen(
                sessionStore = sessionStore,
                onDone = {
                    startMonitoringService(context)
                    navController.navigate(Routes.DONE)
                }
            )
        }
        composable(Routes.DONE) {
            com.parentalcontrol.child.ui.done.SetupCompleteScreen()
        }
    }
}

private fun startMonitoringService(context: android.content.Context) {
    val intent = Intent(context, MonitoringForegroundService::class.java)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        ContextCompat.startForegroundService(context, intent)
    } else {
        context.startService(intent)
    }
}
