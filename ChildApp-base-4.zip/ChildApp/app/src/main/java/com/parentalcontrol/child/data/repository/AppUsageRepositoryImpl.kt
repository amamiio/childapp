package com.parentalcontrol.child.data.repository

import android.app.usage.UsageStatsManager
import android.content.Context
import com.parentalcontrol.child.domain.model.AppUsageSample
import com.parentalcontrol.child.domain.repository.AppUsageRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import javax.inject.Inject

class AppUsageRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : AppUsageRepository {

    override suspend fun getUsageForToday(): List<AppUsageSample> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val now = System.currentTimeMillis()

        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, startOfDay, now)
        return stats
            .filter { it.totalTimeInForeground > 0 }
            .map { AppUsageSample(it.packageName, it.totalTimeInForeground) }
    }
}
