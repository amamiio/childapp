package com.parentalcontrol.child.data.remote

import com.parentalcontrol.child.data.remote.dto.AckDto
import com.parentalcontrol.child.data.remote.dto.AppUsagePayloadDto
import com.parentalcontrol.child.data.remote.dto.InstalledAppsPayloadDto
import com.parentalcontrol.child.data.remote.dto.LocationBatchDto
import com.parentalcontrol.child.data.remote.dto.NotificationBatchDto
import com.parentalcontrol.child.data.remote.dto.PairRequestDto
import com.parentalcontrol.child.data.remote.dto.PairResponseDto
import com.parentalcontrol.child.data.remote.dto.PendingCommandsDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/**
 * All Child <-> Server communication. The Child app never talks to the
 * Parent app directly; every exchange goes through this authenticated
 * REST API over HTTPS.
 */
interface ChildApiService {

    @POST("v1/child/pair")
    suspend fun pair(@Body request: PairRequestDto): Response<PairResponseDto>

    @POST("v1/child/location/batch")
    suspend fun uploadLocationBatch(@Body batch: LocationBatchDto): Response<AckDto>

    @POST("v1/child/installed-apps")
    suspend fun uploadInstalledApps(@Body payload: InstalledAppsPayloadDto): Response<AckDto>

    @POST("v1/child/app-usage")
    suspend fun uploadAppUsage(@Body payload: AppUsagePayloadDto): Response<AckDto>

    @POST("v1/child/notifications/batch")
    suspend fun uploadNotificationBatch(@Body batch: NotificationBatchDto): Response<AckDto>

    @GET("v1/child/commands")
    suspend fun getPendingCommands(): Response<PendingCommandsDto>
}
