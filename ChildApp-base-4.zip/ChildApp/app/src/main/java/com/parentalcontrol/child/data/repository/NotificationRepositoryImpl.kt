package com.parentalcontrol.child.data.repository

import com.parentalcontrol.child.data.local.dao.NotificationDao
import com.parentalcontrol.child.data.local.entity.NotificationEntity
import com.parentalcontrol.child.domain.model.NotificationEvent
import com.parentalcontrol.child.domain.repository.NotificationRepository
import javax.inject.Inject

class NotificationRepositoryImpl @Inject constructor(
    private val dao: NotificationDao
) : NotificationRepository {

    override suspend fun recordNotification(event: NotificationEvent) {
        dao.insert(
            NotificationEntity(
                packageName = event.packageName,
                title = event.title,
                text = event.text,
                postedAtEpochMillis = event.postedAtEpochMillis
            )
        )
    }

    override suspend fun getUnsyncedNotifications(): List<NotificationEvent> =
        dao.getUnsynced().map {
            NotificationEvent(it.packageName, it.title, it.text, it.postedAtEpochMillis)
        }

    override suspend fun markNotificationsSynced(upToEpochMillis: Long) {
        dao.markSynced(upToEpochMillis)
    }
}
