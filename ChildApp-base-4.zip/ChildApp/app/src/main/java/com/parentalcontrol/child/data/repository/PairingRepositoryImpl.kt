package com.parentalcontrol.child.data.repository

import android.os.Build
import com.parentalcontrol.child.data.local.SessionStore
import com.parentalcontrol.child.data.remote.ChildApiService
import com.parentalcontrol.child.data.remote.dto.PairRequestDto
import com.parentalcontrol.child.domain.model.PairingResult
import com.parentalcontrol.child.domain.repository.PairingRepository
import javax.inject.Inject

class PairingRepositoryImpl @Inject constructor(
    private val api: ChildApiService,
    private val sessionStore: SessionStore
) : PairingRepository {

    override suspend fun pairWithCode(code: String): PairingResult {
        return try {
            val response = api.pair(
                PairRequestDto(
                    password = code,
                    deviceModel = Build.MODEL,
                    osVersion = Build.VERSION.RELEASE
                )
            )
            val body = response.body()
            if (response.isSuccessful && body?.success == true &&
                body.authToken != null && body.childDeviceId != null
            ) {
                sessionStore.savePairing(body.authToken, body.childDeviceId)
                PairingResult(success = true, childDeviceId = body.childDeviceId)
            } else {
                PairingResult(success = false, errorMessage = body?.errorMessage ?: "pairing_failed")
            }
        } catch (e: Exception) {
            PairingResult(success = false, errorMessage = e.message)
        }
    }

    override suspend fun isPaired(): Boolean = sessionStore.currentToken() != null

    override suspend fun currentChildDeviceId(): String? = sessionStore.currentDeviceId()
}
