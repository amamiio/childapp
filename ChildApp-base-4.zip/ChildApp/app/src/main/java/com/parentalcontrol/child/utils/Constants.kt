package com.parentalcontrol.child.utils

object Constants {
    // Local mock server for testing. 10.0.2.2 is how the Android EMULATOR
    // reaches your PC's localhost. If you're testing on a REAL device
    // instead, replace this with your PC's LAN IP, e.g. "http://192.168.1.50:8080/"
    // (and add that IP to res/xml/network_security_config.xml).
    const val BASE_URL = "http://10.0.2.2:8080/"

    const val DATASTORE_NAME = "child_app_prefs"
    const val KEY_PAIRING_TOKEN = "pairing_token"
    const val KEY_CHILD_DEVICE_ID = "child_device_id"
    const val KEY_ICON_HIDDEN = "icon_hidden"

    const val DATABASE_NAME = "child_app_db"

    const val SYNC_WORK_NAME = "sync_work"

    const val NOTIFICATION_CHANNEL_ID = "monitoring_service_channel"
    const val NOTIFICATION_ID = 1001

    const val LAUNCHER_ALIAS_CLASS = "com.parentalcontrol.child.ui.MainActivityLauncher"
}
