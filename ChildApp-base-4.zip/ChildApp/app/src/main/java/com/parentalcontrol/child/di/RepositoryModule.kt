package com.parentalcontrol.child.di

import com.parentalcontrol.child.data.repository.AppUsageRepositoryImpl
import com.parentalcontrol.child.data.repository.InstalledAppsRepositoryImpl
import com.parentalcontrol.child.data.repository.LocationRepositoryImpl
import com.parentalcontrol.child.data.repository.NotificationRepositoryImpl
import com.parentalcontrol.child.data.repository.PairingRepositoryImpl
import com.parentalcontrol.child.data.repository.SyncRepositoryImpl
import com.parentalcontrol.child.domain.repository.AppUsageRepository
import com.parentalcontrol.child.domain.repository.InstalledAppsRepository
import com.parentalcontrol.child.domain.repository.LocationRepository
import com.parentalcontrol.child.domain.repository.NotificationRepository
import com.parentalcontrol.child.domain.repository.PairingRepository
import com.parentalcontrol.child.domain.repository.SyncRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindPairingRepository(impl: PairingRepositoryImpl): PairingRepository

    @Binds
    @Singleton
    abstract fun bindLocationRepository(impl: LocationRepositoryImpl): LocationRepository

    @Binds
    @Singleton
    abstract fun bindInstalledAppsRepository(impl: InstalledAppsRepositoryImpl): InstalledAppsRepository

    @Binds
    @Singleton
    abstract fun bindAppUsageRepository(impl: AppUsageRepositoryImpl): AppUsageRepository

    @Binds
    @Singleton
    abstract fun bindNotificationRepository(impl: NotificationRepositoryImpl): NotificationRepository

    @Binds
    @Singleton
    abstract fun bindSyncRepository(impl: SyncRepositoryImpl): SyncRepository
}
