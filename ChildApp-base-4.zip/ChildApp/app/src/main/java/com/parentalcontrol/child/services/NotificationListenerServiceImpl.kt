package com.parentalcontrol.child.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.parentalcontrol.child.domain.model.NotificationEvent
import com.parentalcontrol.child.domain.repository.NotificationRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class NotificationListenerServiceImpl : NotificationListenerService() {

    @Inject lateinit var notificationRepository: NotificationRepository

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Never capture this app's own notifications.
        if (sbn.packageName == packageName) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString()
        val text = extras.getCharSequence("android.text")?.toString()

        scope.launch {
            notificationRepository.recordNotification(
                NotificationEvent(
                    packageName = sbn.packageName,
                    title = title,
                    text = text,
                    postedAtEpochMillis = sbn.postTime
                )
            )
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // No-op for now; removal events aren't currently synced.
    }
}
