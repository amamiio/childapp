package com.parentalcontrol.child.ui.connect

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.parentalcontrol.child.domain.repository.PairingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface ConnectUiState {
    data object Idle : ConnectUiState
    data object Loading : ConnectUiState
    data object Success : ConnectUiState
    data class Error(val message: String) : ConnectUiState
}

@HiltViewModel
class ConnectViewModel @Inject constructor(
    private val pairingRepository: PairingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ConnectUiState>(ConnectUiState.Idle)
    val uiState: StateFlow<ConnectUiState> = _uiState.asStateFlow()

    fun submitCode(code: String) {
        if (code.isBlank()) {
            _uiState.value = ConnectUiState.Error("empty_code")
            return
        }
        _uiState.value = ConnectUiState.Loading
        viewModelScope.launch {
            val result = pairingRepository.pairWithCode(code.trim())
            _uiState.value = if (result.success) {
                ConnectUiState.Success
            } else {
                ConnectUiState.Error(result.errorMessage ?: "unknown_error")
            }
        }
    }
}
