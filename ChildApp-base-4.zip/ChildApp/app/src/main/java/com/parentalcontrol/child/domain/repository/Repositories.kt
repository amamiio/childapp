package com.parentalcontrol.child.domain.repository

import com.parentalcontrol.child.domain.model.AppUsageSample
import com.parentalcontrol.child.domain.model.InstalledAppInfo
import com.parentalcontrol.child.domain.model.LocationSample
import com.parentalcontrol.child.domain.model.LockedAppRule
import com.parentalcontrol.child.domain.model.NotificationEvent
import com.parentalcontrol.child.domain.model.PairingResult
import kotlinx.coroutines.flow.Flow

interface PairingRepository {
    suspend fun pairWithCode(code: String): PairingResult
    suspend fun isPaired(): Boolean
    suspend fun currentChildDeviceId(): String?
}

interface LocationRepository {
    suspend fun recordLocation(sample: LocationSample)
    suspend fun getUnsyncedLocations(): List<LocationSample>
    suspend fun markLocationsSynced(upToEpochMillis: Long)
}

interface InstalledAppsRepository {
    suspend fun getInstalledApps(): List<InstalledAppInfo>
    fun observeLockedApps(): Flow<List<LockedAppRule>>
    suspend fun setLockedApps(rules: List<LockedAppRule>)
}

interface AppUsageRepository {
    suspend fun getUsageForToday(): List<AppUsageSample>
}

interface NotificationRepository {
    suspend fun recordNotification(event: NotificationEvent)
    suspend fun getUnsyncedNotifications(): List<NotificationEvent>
    suspend fun markNotificationsSynced(upToEpochMillis: Long)
}

interface SyncRepository {
    /** Pushes all pending locally-cached data to the server, and pulls any
     *  pending commands (e.g. updated lock list) from the parent. */
    suspend fun syncAll(): Boolean
}
