package com.parentalcontrol.child.ui.permissions

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.parentalcontrol.child.utils.PermissionUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class PermissionKey {
    LOCATION, NOTIFICATION_LISTENER, ACCESSIBILITY, USAGE_ACCESS, MEDIA, DEVICE_ADMIN
}

data class PermissionUiState(
    val key: PermissionKey,
    val granted: Boolean
)

class PermissionsViewModel(application: Application) : AndroidViewModel(application) {

    private val _states = MutableStateFlow(
        PermissionKey.entries.map { PermissionUiState(it, granted = false) }
    )
    val states: StateFlow<List<PermissionUiState>> = _states.asStateFlow()

    fun refresh() {
        viewModelScope.launch {
            val context = getApplication<Application>()
            _states.value = PermissionKey.entries.map { key ->
                val granted = when (key) {
                    PermissionKey.LOCATION -> PermissionUtils.hasPermission(
                        context, android.Manifest.permission.ACCESS_FINE_LOCATION
                    )
                    PermissionKey.NOTIFICATION_LISTENER -> PermissionUtils.isNotificationListenerEnabled(context)
                    PermissionKey.ACCESSIBILITY -> PermissionUtils.isAccessibilityServiceEnabled(context)
                    PermissionKey.USAGE_ACCESS -> PermissionUtils.hasUsageAccess(context)
                    PermissionKey.MEDIA -> PermissionUtils.hasPermission(
                        context, android.Manifest.permission.READ_MEDIA_IMAGES
                    )
                    PermissionKey.DEVICE_ADMIN -> PermissionUtils.isDeviceAdminActive(context)
                }
                PermissionUiState(key, granted)
            }
        }
    }

    fun allRequiredGranted(): Boolean =
        _states.value.filter { it.key != PermissionKey.DEVICE_ADMIN }.all { it.granted }
}
