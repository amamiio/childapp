package com.parentalcontrol.child.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.parentalcontrol.child.data.local.dao.LocationDao
import com.parentalcontrol.child.data.local.dao.LockedAppRuleDao
import com.parentalcontrol.child.data.local.dao.NotificationDao
import com.parentalcontrol.child.data.local.entity.LocationEntity
import com.parentalcontrol.child.data.local.entity.LockedAppRuleEntity
import com.parentalcontrol.child.data.local.entity.NotificationEntity

@Database(
    entities = [LocationEntity::class, NotificationEntity::class, LockedAppRuleEntity::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun locationDao(): LocationDao
    abstract fun notificationDao(): NotificationDao
    abstract fun lockedAppRuleDao(): LockedAppRuleDao
}
