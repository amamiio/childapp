package com.parentalcontrol.child.services

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.parentalcontrol.child.R

/**
 * Requests no special policies (see device_admin_policies.xml). Its only
 * purpose is that Android requires a user to explicitly deactivate device
 * admin rights (Settings > Security > Device admin apps) before this app
 * can be uninstalled -- preventing a quick, accidental removal while still
 * leaving uninstall fully possible for whoever holds the device.
 */
class DeviceAdminReceiverImpl : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        Toast.makeText(context, context.getString(R.string.permission_device_admin_title), Toast.LENGTH_SHORT).show()
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return context.getString(R.string.permission_device_admin_body)
    }
}
