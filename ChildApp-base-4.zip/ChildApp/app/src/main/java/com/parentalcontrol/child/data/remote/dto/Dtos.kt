package com.parentalcontrol.child.data.remote.dto

data class PairRequestDto(
    val password: String,
    val deviceModel: String,
    val osVersion: String
)

data class PairResponseDto(
    val success: Boolean,
    val childDeviceId: String?,
    val authToken: String?,
    val errorMessage: String?
)

data class LocationBatchDto(
    val samples: List<LocationSampleDto>
)

data class LocationSampleDto(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val capturedAtEpochMillis: Long
)

data class InstalledAppsPayloadDto(
    val apps: List<InstalledAppDto>
)

data class InstalledAppDto(
    val packageName: String,
    val appLabel: String,
    val isSystemApp: Boolean
)

data class AppUsagePayloadDto(
    val usage: List<AppUsageDto>
)

data class AppUsageDto(
    val packageName: String,
    val foregroundMillisToday: Long
)

data class NotificationBatchDto(
    val events: List<NotificationEventDto>
)

data class NotificationEventDto(
    val packageName: String,
    val title: String?,
    val text: String?,
    val postedAtEpochMillis: Long
)

/** Commands the parent has queued for this device (e.g. updated lock list). */
data class PendingCommandsDto(
    val lockedPackages: List<String>
)

data class AckDto(val success: Boolean)
